from django.apps import AppConfig


class QlkhohangConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'qlkhohang'
