# from django.shortcuts import render
# from .models import KhoForm
# def welcome_view(request):
#     id = KHO.objects.all()
#     context = {
#         'ten_list': ten_list,
#         'diachi_list': ten_list,
#         'mathang_list': ten_list,
#     }
#     # Render template và trả về HTTP response
#     return render(request, 'welcome.html', context)