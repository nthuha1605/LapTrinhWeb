from django.db import models
class MATHANG(models.Model):
    id = models.AutoField(primary_key=True)
    Ten = models.CharField(max_length=255, null=False)
    MoTa = models.TextField(null=True)
    DVT = models. CharField(max_length=255, null=True)
    def __str__(self):
        return self.id
#hang = MATHANG.objects.create(Ten='Ly',MoTa='Con Hang', DVT='cai')

class KHO(models.Model):
    id = models.AutoField(primary_key=True)
    Ten = models.CharField(max_length=255, null=True)
    DiaChi = models.CharField(max_length=255, null=True)
    MatHang = models.ForeignKey(MATHANG, on_delete=models.CASCADE)
    def __str__(self):
        return self.id
# kho = KHO.objects.create(id='1', Ten='Kho1',DiaChi='DacLac',MatHang='A')
class KHOMATHANG(models.Model):
    id = models.AutoField(primary_key=True)
    MatHang = models.ForeignKey(MATHANG, on_delete=models.CASCADE)
    Kho = models.ForeignKey(KHO, on_delete=models.CASCADE)
    SoLuong = models.IntegerField(null=False)

#from qlkhohang import MATHANG, KHO, KHOMATHANG

