from django.db import models

class Contributor(models.Model):
    first_names = models.CharField(max_length=255)
    last_names = models.CharField(max_length=255)

    def initialled_name(self):
        """Trả về chuỗi chứa Họ và Tên của contributor, hai phần này cách nhau bởi dấu phẩy (,)."""
        return f"{self.last_names}, {self.first_names[:1]}"

class Book(models.Model):
    title = models.CharField(max_length=255)
    contributors = models.ManyToManyField(Contributor, related_name='books')