from django.contrib import admin

admin.site.site_header = "c8admin"